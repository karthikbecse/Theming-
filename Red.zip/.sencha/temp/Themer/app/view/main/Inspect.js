var toolkit = Ext.toolkit;

Ext.define('Viewer.view.main.Inspect', {

    requires: [
        'Ext.util.Event',
        'Viewer.view.Highlighter'
    ],

    socketEventQueue: [],
    componentTree: null,
    componentTreeTimeStamp: null,

    initInspect: function() {
        this.watchComponentTree();
        this.initFashion();
        this.initPolyfills();
        this.socketPort = document.head.getAttribute('data-senchathemerport') || 8900;
        this.socketDomain = document.location.protocol + '//localhost:' + this.socketPort;

        Ext.Loader.loadScript({
            url: this.socketDomain + '/socket.io/socket.io.js?nc=' + new Date().getTime(),
            onLoad: this.connect.bind(this)
        });

        this.initElementSelectors();

        function addEvent(obj, evt, fn) {
            if (obj.addEventListener) {
                obj.addEventListener(evt, fn, false);
            }
            else if (obj.attachEvent) {
                obj.attachEvent("on" + evt, fn);
            }
        }
        // Toggle inspect on 'CmdOrCtrl+I' inside the app directly.
        addEvent(document, 'keypress', function(e) {
            if(((Ext.isMac && e.metaKey) || (!Ext.isMac && e.ctrlKey)) && e.key === 'i') {
                this.socketEmit('toggleInspect');
                e.preventDefault();
                e.stopPropagation();
            }
        }.bind(this));

        addEvent(document, 'mouseout', function(e) {
            e = e || window.event;
            var from = e.relatedTarget || e.toElement;
            if(!from || from.nodeName === 'HTML') {
                this.hoverHighlighter.hide();
            }
        }.bind(this));

        addEvent(document, 'mouseover', function(e) {
            if(this.inspectEnabled) {
                this.hoverHighlighter.show();
            }
        }.bind(this));
    },

    /**
     * Watches the component tree for changes
     */
    watchComponentTree: function() {
        new MutationObserver(function() {
            this.componentTree = null; 
        }.bind(this)).observe(document.body, {
            childList: true, 
            subtree: true
        });
    },

    connect: function() {
        this.socket = io(this.socketDomain+'/inspector')
            .on('connect', function() {
                if (this.fireEvent) {
                    // fireEvent won't be available when running in an app, but this is only needed in the viewer
                    // to ensure that the initial setVariables call to set $themer-mixin-schema-timestamp happens
                    // once the socket is connected
                    this.fireEvent('socketconnect');
                }
            }.bind(this))
            .on('toggleHighlight', function (data) {
                this.toggleHighlight(data);
            }.bind(this))
            .on('selectElement', function (data) {
                this.selectElement(data);
            }.bind(this))
            .on('toggleInspect', function(data) {
                this.toggleInspectEnabled(data);       
            }.bind(this))
            .on('clearInspect', function() {
                this.hoverHighlighter.hide();
                this.selectHighlighter.hide();
            }.bind(this))
            .on('setVariables', function(data) {
                this.setVariables(data.variables);
            }.bind(this))
            .on('getInfo', this.getAppInfo.bind(this))
            .on('setup', function() {
                this.socketEventQueue.forEach(function(evt) {
                    this.socket.emit(evt.event, evt.data);
                }.bind(this));
                this.socketEventQueue = [];
            }.bind(this));
    },

    /**
     * selects a component in the viewer or app upon selecting a node in the tree
     * @param {Object} data - node data
     */
    selectElement : function (data) {
        var me = this;
        var cmpId = data.cmpId;
        if (cmpId) {
            var cmp = Ext.get(data.cmpId);
            if (cmp) {
                me.selectHighlighter.highlight(cmp.dom);
                me.postSelectedElement(cmp.dom);
            }            
        }
    },

    /**
     * toggles highlight on a component in a viewer or app upon hovering a node in the tree
     * @param {Object} data - node data
     */
    toggleHighlight : function (data) {
        var cmpId = data.cmpId;
        if (cmpId) {
            var cmp = Ext.get(data.cmpId);
            if (cmp) {
                data.highlight ? this.hoverHighlighter.highlight(cmp) : this.hoverHighlighter.hide(cmp);
            }            
        }
    },

    /**
     * Toggles the frozen state of the app.  When frozen, all events are suspended.  This allows the
     * user to style app in a specific state, such as hovering over a button, or with a popup menu open.
     * @param {Boolean} freeze
     */
    toggleFrozen: function(freeze) {
        Ext.util.Event.prototype.suspended = freeze || this.inspectEnabled;
    },

    socketEmit: function(event, data) {
        if(this.socket) {
            this.socket.emit(event, data);
        } else {
            this.socketEventQueue.push({event: event, data: data});
        }
    },

    privates: {
        /**
         * The currently selected element
         * @property {HTMLElement}
         */
        selectedEl: null,

        /**
         * @property {Boolean}
         * True if the inspect toggle button is checked
         */
        inspectEnabled: false,

        /**
         * Data from inspect.json, passed in as part of the toggleInspect message
         */
        inspectData : null,

        /**
         * Classes that actually have a 'default' UI defined
         */
        requireDefaultUIFor: {
            'classic:Ext.tab.Tab': true
        },

        view: null
    },

    /**
     * Creates the element selectors for inspect mode
     */
    initElementSelectors: function() {
        var me = this;

        this.selectHighlighter = Ext.create({
            xtype: 'c-highlighter',
            type: 'select'
        });

        this.hoverHighlighter = Ext.create({
            xtype: 'c-highlighter',
            type: 'hover'
        });

        document.body.addEventListener('mouseover', function(event) {
            if (!me.inspectEnabled) return;
            var target = event.target;

            if (!me.matchesDomSelector(target)) {
                var cmp = Ext.Component.fromElement(target);
                target = cmp && cmp.el.dom;
            }

            me.hoverEl = target;

            if (target && !Ext.fly(target).hasCls('c-no-inspect')) {
                me.hoverHighlighter.highlight(target);
            } else {
                me.hoverHighlighter.hide();
                target = null;
            }
        });

        // prevent itemtap events in modern when inspect is enabled
        document.body.addEventListener('mouseup', function(event) {
            if (me.inspectEnabled) event.stopPropagation();
        }, true);

        document.body.addEventListener('click', function(event) {
            if (me.inspectEnabled && me.hoverEl && !Ext.fly(me.hoverEl).hasCls('c-no-inspect')) {
                me.selectHighlighter.highlight(me.hoverEl);
                me.postSelectedElement(me.hoverEl);
                event.stopPropagation();
            }
        }, true);
    },

    matchesDomSelector: function(el) {
        for (var selector in this.inspectData.domSelectors) {
            if (el.matches(selector)) {
                return true;
            }
        }
    },

    /**
     * Returns variables for the selected element
     * @param {DOMElement} el selected element
     * @returns {Object} Keys are sass variables for the selected component
     */
    getVariablesOnInspect: function (el) {
        var cmp = Ext.Component.fromElement(el);
        if (!cmp) return [];

        var result = { variables: {}, uiVariables: {}},
            className = cmp.$className;

        if (className.indexOf('Ext.') === -1) {
            className = this.getProtoClassName(cmp);
        }

        this.addVariablesForDOMSelectors(el, result.variables);

        if (cmp && cmp.el) {
            var ui = this.getUiVariablesFor(cmp, className, result),
                variablesForCmp = this.inspectData.components[className] || {};

            this.applySelectors(cmp, variablesForCmp);

            // add variables from doxi
            for (var v in variablesForCmp) {
                v = v.replace(/-/g, '_');

                // if the component has a ui, make sure that the variable is listed under than ui in inspect.json
                if (!ui || ui.hasOwnProperty(v)) result.variables[v] = className;
            }
        }

        if(Object.keys(result.variables).length > 0) {
            return result;
        } else {
            // Recursively get variables from parent component until we get variables, however, retain uiName.
            var uiName = result.uiName;
            var newResult = this.getVariablesOnInspect(cmp.el.parent().dom);
            newResult.uiName = uiName;
            return newResult;
        }
    },

    /**
     * Handle some special cases of UIs, when a UI is applied to a component, the default UIs should still
     * subset the variables set back (inspect.json "uis" property).
     *
     * An example of this is button in classic.  By default {xtype: 'button', ui: 'my-ui'} will result in
     * activeUI being set to 'my-ui-small'.  This function will ensure subset variables are looked up from inspect.json
     * for 'default-small' and also set uiName on the result to 'my-ui' instead of 'my-ui-small', so the names match
     * what is expected.
     *
     * @param cmp
     * @param result The result that will be sent back to Editor (elementSelected).  This function will set the proper 'uiName' on the result
     *                  so the Editor can lookup the correct UI for the selected component.
     */
    getUiVariablesFor: function(cmp, className, result) {
        var me = this,
            activeUi = me.getActiveUI(cmp);

        if(activeUi) {
            var activeUis = activeUi.split(' ');

            if(Ext.toolkit === 'classic') {
                // Button, remove small, medium, large suffix from uiName and grab default-(scale) for ui inspect data.
                if(cmp instanceof Ext.button.Button) {
                    // Is there a better way to detect if this is a Toolbar button!?!?!?!
                    if(cmp.up('toolbar')) {
                        result.uiName = activeUis.filter(function(ui){return !me.inspectData.uis[ui];}).map(function(ui){return ui.replace(/-toolbar-(small|medium|large)/i, '');}).join(' ');
                        var inspectUiData = {};
                        activeUis.forEach(function(ui) {
                            var match = ui.match(/-toolbar-(small|medium|large)$/i);
                            Object.assign(inspectUiData, me.inspectData.uis[(match ? 'default-toolbar-' + match[1] : 'default')]);
                        });
                        return inspectUiData;
                    } else {
                        result.uiName = activeUis.filter(function(ui){return !me.inspectData.uis[ui];}).map(function(ui){return ui.replace(/-(small|medium|large)/i, '');}).join(' ');
                        var inspectUiData = {};
                        activeUis.forEach(function(ui) {
                            var match = ui.match(/-(small|medium|large)$/i);
                            Object.assign(inspectUiData, me.inspectData.uis[(match ? 'default-' + match[1] : 'default')]);
                        });
                        return inspectUiData;
                    }
                // Panel, remove framed suffix (if exists) and grab default-framed or default from ui inspect data.
                } else if(cmp instanceof Ext.panel.Panel) {
                    result.uiName = activeUis.filter(function(ui){return !me.inspectData.uis[ui];}).map(function(ui){return ui.replace(/-framed/);}).join(' ');
                    var inspectUiData = {};
                    activeUis.forEach(function(ui) {
                        var match = ui.match(/-framed$/i);
                        if(match) {
                            Object.assign(inspectUiData, me.inspectData.uis['default-framed']);
                        }
                    });
                    return Object.keys(inspectUiData).length > 0 ? inspectUiData : null;
                } else {
                    result.uiName = activeUis.filter(function(ui){return !me.inspectData.uis[ui];}).join(' ');
                    var inspectUiData = {};
                    activeUis.forEach(function(ui) {
                        if(ui !== 'default' && me.inspectData.uis[activeUi]) {
                            Object.assign(inspectUiData, me.inspectData.uis[activeUi]);
                        }
                    });
                    return Object.keys(inspectUiData).length > 0 ? inspectUiData : null;
                }
            }

            // If we've reached here, do the default things.
            result.uiName = activeUi;
            var inspectUiData = {};
            activeUis.forEach(function(ui) {
                // Only add ui if it's not the 'default' UI OR special case.
                if(ui !== 'default' || me.requireDefaultUIFor[Ext.toolkit + ':' + className]) {
                    Object.assign(inspectUiData, me.inspectData[ui] || me.inspectData['default']);
                }
            });
            return Object.keys(inspectUiData).length > 0 ? inspectUiData : null;
        }
    },

    /**
     * Adds variables for matching domSelectors from inspect.json
     * @param {DOMElement} el
     * @param {Object} variables
     */
    addVariablesForDOMSelectors: function(el, variables) {
        for (var selector in this.inspectData.domSelectors) {
            if (el.matches(selector)) {
                var show = this.inspectData.domSelectors[selector];

                for (var v in show) {
                    var key = v.replace(/-/g, '_');

                    if (show[v]) {
                        variables[key] = true;
                    } else {
                        delete variables[key];
                    }
                }
            }
        }
    },

    /**
     * For any matching selectors in inspect.json, this function adds the variables listed under show and removes the variables listed under hide
     * @param {Ext.Component} cmp
     * @param {Object} variables The list of variables for the component based on class
     */
    applySelectors: function(cmp, variables) {
        for (var selector in this.inspectData.selectors) {
            var show = this.inspectData.selectors[selector];

            try {
                if (Ext.ComponentQuery.is(cmp, selector)) {
                    for (var v in show) {
                        if (show[v]) {
                            variables[v] = true;
                        } else {
                            delete variables[v];
                        }
                    }
                }
            } catch (e) {
                // console.warn('error in selector: ' + selector, e)
            }
        }
    },

    /**
     * Turns inspection on or off
     * @param {Boolean} enabled
     * @param {Object} inspectData The contents of inspect.json
     */
    toggleInspectEnabled: function(data) {
        this.inspectEnabled = data.value;
        this.inspectData = data.inspectData;
        this.toggleFrozen(data.enabled);
        
        if (!this.inspectEnabled) {
            this.selectHighlighter.hide();
            this.hoverHighlighter.hide();
            this.postSelectedElement(null);
            this.batchLayouts(function() {
                // reload the preview - freezing events can put the preview in a weird visual state, such as frozen menu selections that don't reset unless clicked.
                if (this.previewId) this.show(this.previewId, this.uiName);

                try {
                    this.getView().plugins[0].updateResponsiveState(); // make viewport redraw
                } catch (e) {
                    // just move on if there is an error here
                }
            }, this);
        } else if (data.value && this.isViewer) {
            data.componentTree = this.getComponentTree();
            this.socketEmit('initComponentTree', data);    
        }
    },

    /**
     * Stub batchLayouts in modern
     */
    batchLayouts: Ext.batchLayouts || function(cb, scope) { cb.call(scope) },

    /**
     * Gets feature class names for Ext.panel.Table instances
     * @param {Node} childNode - child node
     * @returns {Array} - Feature class names
     */
    getFeatureClassNames : function (childNode) {
        var featureClassNames = [];
        var viewNode = childNode.getView();

        var features = viewNode.features;
        for (var i=0; i < features.length; i++) {
            var feature = features[i];
            if (feature) {
                var className = feature.__proto__['$className'];
                if (!Ext.Array.contains(featureClassNames, className)) {
                    featureClassNames.push(className);
                }
            }
        }
        return featureClassNames;
    },

    /**
     * Looks for Ext component class in the inheritance chain
     * @param {Node} childNode
     * @returns {String} Class Name
     */
    getProtoClassName : function (childNode) {
        if (childNode) {
            var proto = childNode.__proto__;
            if (proto && proto['$className']) {
                var className = proto['$className'];

                if (className && className.indexOf('Ext.') !== -1) {
                    return className;
                } else {
                    return this.getProtoClassName(proto);
                }

            }
        }
    },

    /**
     * Sends the css classes for the specified element and its ancestors to the editor app
     * @param {Node/HTMLElement} el
     */
    postSelectedElement: function(el) {
        var data = Ext.apply({}, el && this.getVariablesOnInspect(el), {
            appName: Ext.manifest.name,
            componentTree: this.getComponentTree(),
            inspectTimeStamp: this.componentTreeTimeStamp,
            elId: el && Ext.ComponentManager.fromElement(el).getId(),
            toolkit: Ext.toolkit,
            bigMode: Ext.fly(document.documentElement).hasCls('x-big')
        });

        this.socketEmit('elementSelected', data);
    },

    /**
     * Extracts data for the component tree
     */
    getComponentTree: function() {
        if (!this.componentTree) {
            var rootFilter;

            if (Ext.toolkit === 'modern') {
                rootFilter = function(comp) {
                    return !comp.parent && !(comp instanceof Ext.slider.Thumb ||
                                            comp instanceof Ext.slider.Slider ||
                                            // 6.0 modern TextInput and Trigger are not classes.
                                            (Ext.field.TextInput && comp instanceof Ext.field.TextInput) ||
                                            (Ext.field.trigger && comp instanceof Ext.field.trigger.Trigger))
                } 
            } else {
                rootFilter = function(comp) {
                    return !comp.ownerCt && !(comp instanceof Ext.menu.Menu || comp instanceof Ext.dd.StatusProxy);
                }
            }

            this.componentTree = this.getComponentTreeNodes(Ext.ComponentManager.getAll().filter(rootFilter))
            this.componentTreeTimeStamp = new Date().getTime();
        }

        return this.componentTree;
    },

    /**
     * recursive function to loop through items / docked items and children. compiles master list of components.
     * @param {Array} comps - app / viewer components
     */
    getComponentTreeNodes: function (comps) {
        var me = this;
        var compNodes = [];
        if (!comps) return;

        if (!Ext.isArray(comps)) {
            comps = [ comps ];
        }

        Ext.each (comps, function (comp) {
            // don't show unused rows in modern buffered grids
            if (Ext.grid.Row && comp instanceof Ext.grid.Row && comp.$hidden) return;

            // don't show the highlighters
            if (comp.hideFromComponentTree) return;

            var node = me.getCompNodeForComp (comp),
                items = Ext.ComponentQuery.query('> *', comp);

            // modern sliders
            if (comp.thumbs) items = items.concat(comp.thumbs); 
            
            // modern triggerfields
            if (Ext.isObject(comp._triggers)) {
                for (var key in comp._triggers) {
                    items.push(comp._triggers[key])
                }    
            }

            // modern Ext.list.Tree nodes
            if (Ext.list.Tree && comp instanceof Ext.list.Tree) {
                for (var key in comp.itemMap) {
                    items.push(comp.itemMap[key])
                }
            }

            Ext.each(me.getComponentTreeNodes(items), function (child) {
                node.children.push(child);
            });

            if (node.children.length === 0) node.leaf = true;
            compNodes.push(node);
        });

        return compNodes;
    },

    /**
     * returns an active ui for a component
     * @param {Ext.Component} component - ext component
     */
    getActiveUI : function (comp) {
        if (Ext.list && Ext.list.TreeItem && comp instanceof Ext.list.TreeItem) {
            return this.getActiveUI(comp.parent); // the UI is defined for the tree item, but configured on the treelist
        }

        return comp.getUi ? comp.getUi() : comp.getUI ? comp.getUI() : comp.activeUI;
    },

    /**
     * retrieves component details.
     * @param {Component} comp - component
     */
    getCompNodeForComp : function (comp) {
        // text is constructed with xtype(s), reference(s), itemId(s) or id(s)
        var activeUi = this.getActiveUI(comp);
        var text = '<b>' + comp.xtype + '</b>';

        if (comp.reference) {
            text += ' reference=' + comp.reference;
        } else if (comp.itemId) {
            text += ' itemId=' + comp.itemId;
        } else if (comp.id) {
            text += '#' + comp.id;
        }

        var extJSClass = this.getClassForComp(comp)
       
        return {
            text : text,
            cmpId  : comp.id || '',
            ui : (activeUi && activeUi !== 'default' ? activeUi : ''),
            extClass: extJSClass && extJSClass.$className,
            xtype : extJSClass && extJSClass.xtype,
            children : [],
        };
    },

    /**
     * Returns the name of the Ext JS class from which the component extends.
     * @param {Ext.Base} comp
     * @return {String}
     */
    getClassForComp: function(comp) {
        var proto = comp.__proto__;

        while (proto && proto.$className.indexOf('Ext.') !== 0) {
            proto = proto.__proto__;
        }

        return proto;
    },

    /**
     * Stolen from Sencha Inspector, get's details about the app.
     */
    getAppInfo: function() {
        var browser = 'Other',
            browserVersion = '';

        //Ext.browser only exists in Touch 2.1.0+ and Ext JS 4.2.3+
        if (Ext.browser) {
            browser = Ext.browser.name;
            browserVersion = Ext.browser.version.version;
        }

        var info = {
            browser : (Ext.isSpace === true) ? 'Space' : browser,

            browserVersion : browserVersion,
            framework      : (Ext.versions.extjs) ? 'Ext JS' : 'Sencha Touch',
            version        : Ext.getVersion().version,

            fashionDebug : (window.Fashion !== undefined),

            app : {
                versions : {},
                name     : 'Sencha Application', //if MVC app, overwritten below
                location : window.location.toString(),
                isMVC    : false
            }
        };

        var versions = Ext.versions,
            key;

        for (key in versions) {
            if (versions.hasOwnProperty(key)) {
                info.app.versions[ key ] = versions[ key ].version;
            }
        }

        //remove duplicate entries
        if (info.app.versions.ext === info.app.versions.extjs) {
            delete info.app.versions.ext;
        }
        if (info.app.versions.core === info.app.versions['sencha-core']) {
            delete info.app.versions.core;
        }

        //if Ext JS 6, mention the toolkit
        if (Ext.manifest && Ext.manifest.toolkit) {
            info.app.toolkit = Ext.manifest.toolkit;
        }

        //Get extra Framework/Cmd stuff
        if (Ext.manifest && Ext.manifest.packages) {
            var m = Ext.manifest.packages;

            if (m.ext) {
                info.app.versions.license = m.ext.license;
            }
            if (m.cmd) {
                info.app.versions.cmdCurrent = m.cmd.current;
                info.app.versions.cmdBuild = m.cmd.version;

                //in case there is a duplicate entry
                delete info.app.versions.cmd;
            }
            info.app.theme = Ext.manifest.theme;
        }

        if (Ext.app && Ext.app.Application) {
            var instance = Ext.app.Application.instance;

            if (!instance) {
                for (key in window) {
                    if (window.hasOwnProperty(key) && window[ key ] && window[ key ].app && window[ key ].app.$className) {
                        // get app instance,
                        // save on Ext.app.Application.instance like Ext JS 4+ does since it couldn't find it before
                        instance = Ext.app.Application.instance = window[ key ].app;
                        break;
                    }
                }
            }

            if (instance && instance instanceof Ext.app.Application) {
                // flag that it is an MVC app
                info.app.isMVC = true;

                // get app name
                info.app.name = instance.getName ? instance.getName() : instance.name;
            }
        }

        info.isViewer = this.isViewer;

        this.socketEmit('appInfo', info);
    },


    /**
     * Saves updated variables using fashion
     * @param {Object} variables A map of variable name to value
     * @param {Object} [revertOnError=true] Set to false to prevent automatically reverting to the previous values if a sass complilation error occurs
     */
    setVariables: function(variables, revertOnError) {
        var me = this;

        if (revertOnError === undefined) {
            revertOnError = true;
        }

        var themeVariables = {};
        Object.keys(variables).filter(function(variable) { return variable.indexOf('uisPP') < 0; }).forEach(function(variable) {
            // TODO: CAT-420 Should send hyphens instead of underscores to Fashion.
            themeVariables[variable.replace(/_/g, '-')] = variables[variable];
        });

        // If running in client app, just call Fashion and return (don't care about saved variables and mixins, etc.)
        if(!this.isViewer && Fashion !== undefined) {
            try {
                Fashion.setVariables(themeVariables, function() {
                    try {
                        if (Ext.toolkit === 'classic') {
                            Ext.Component.fromElement(document.body).updateLayout();
                        } else {
                            Ext.get(document.body).repaint();
                        }
                    }catch(e) {/**Swallow**/}

                    if(me.inspectEnabled) me.selectHighlighter.reHighlight();
                }, false, true);
            } catch(err) {
                me.postError(err);
            } finally {
                return;
            }
        }

        var savedVariables = {};
        Object.keys(me.saved).forEach(function(v) {
            savedVariables[v.replace(/_/g, '-')] = me.saved[v];
        });

        try {
            Fashion.setVariables(themeVariables, function() {
                me.getView().updateLayout();
                me.postVariables();
            });
        } catch (err) {
            if (me.saved && revertOnError) {
                me.setVariables(me.saved);
            }
            me.postError(err);
        }
    },

    /**
     * Sends an error to the Editor app
     * @param {Integer} id An id to keep track of the ui event
     */
    postError: function(error) {
        this.socketEmit('sassCompilationError', { message: typeof error === 'string' ? error : error.message });
    },

    initFashion: function() {
        if(window.Fashion === undefined) return;

        // Monkey-patch for SDKTOOLS-1583/1584, Fashion.version will be populated (6.2.1) when proper fix is applied
        // and this code block can safely be removed in future versions of Themer that force Cmd 6.2.1+ support.
        if (Fashion.version === undefined) {
            var onBuildSassFileWas = SassBuilder.onBuildSassFile,
                saveMixinsWas = SassBuilder.setMixins;

            Fashion.apply(SassBuilder, {
                onBuildSassFile: function(update){
                    if (SassBuilder.invalidates) {
                        SassBuilder.saveFileUpdated = false;
                        SassBuilder.skipNextBuild = 0;
                    }

                    if (SassBuilder.skipNextBuild) {
                        Fashion.log("Skipping rebuild.");
                        SassBuilder.skipNextBuild = SassBuilder.skipNextBuild - 1;
                        Fashion.onAfterBuild(false);
                        return false;
                    }

                    if (SassBuilder.saveFileUpdated) {
                        Fashion.log("Applying save file updates.");
                        SassBuilder.saveFileUpdated = false;
                        Fashion.setVariables(Fashion.getSavedVariables(), null, false, true);
                        Fashion.onAfterBuild(false);
                        return false;
                    }

                    SassBuilder.saveFileUpdated = false;
                    onBuildSassFileWas.apply(SassBuilder, arguments);
                    return true;
                },

                saveMixins: function() {
                    SassBuilder.skipNextBuild = 0;
                    saveMixinsWas.apply(SassBuilder, arguments);
                }
            });

            Fashion.apply(Fashion.SassFile.prototype, {
                getCustomUIs: function() {
                    var me = this,
                        mixinMap = {},
                        allUIs = {},
                        calls = me.mixinCalls,
                        separator = ', ',
                        node, mixinName, include, args, arg, argName, argMap, uiMap;
                    allUIs[me.jsClassName] = mixinMap;
                    for (var i = 0; i < calls.length; i++) {
                        node = calls[i];
                        include = node.include;
                        mixinName = include.id || include.value;
                        uiMap = mixinMap[mixinName] || {};
                        args = include.args;
                        if (args.isFashionListAst) {
                            args = args.items;
                            separator = args.separator;
                        }
                        if (!Array.isArray(args)) {
                            args = [args];
                        }
                        argMap = {};
                        for (var a = 0; a < args.length; a++) {
                            arg = args[a];
                            argName = a;
                            var value = arg.name || arg.value;
                            if (arg.variable) {
                                argName = arg.variable;
                            }
                            if (!value) {
                                while(arg && arg.expr) {
                                    arg = arg.expr;
                                }
                                if (arg.isFashionListAst) {
                                    separator = arg.separator || separator;
                                    value = Fashion.convert(arg.items, function(item){
                                        return item.name || item.value;
                                    });
                                    value = '(' + value.join(separator) + ')';
                                }
                                else {
                                    value = arg.name || arg.value;
                                }
                            }
                            argMap[argName] = value;
                        }
                        if (argMap.$ui) {
                            var tmp = {};
                            tmp[argMap.$ui] = argMap;
                            delete argMap.$ui;
                            argMap = tmp;
                        }
                        Fashion.apply(uiMap, argMap);
                        mixinMap[mixinName] = uiMap;
                    }
                    return allUIs;
                }
            });
        }

        Fashion.onAfterBuild = function() {
            if(this.inspectEnabled) this.selectHighlighter.reHighlight();

            // Post variables to Editor app after Fashion build, needed for UIs
            if(this.postVariables) this.postVariables();
            if(this.postMixins) this.postMixins();
        }.bind(this);
    },

    initPolyfills: function() {
        // Element.matches
        if (!Element.prototype.matches) {
            Element.prototype.matches =
                Element.prototype.matchesSelector ||
                Element.prototype.mozMatchesSelector ||
                Element.prototype.msMatchesSelector ||
                Element.prototype.oMatchesSelector ||
                Element.prototype.webkitMatchesSelector ||
                function(s) {
                    var matches = (this.document || this.ownerDocument).querySelectorAll(s),
                        i = matches.length;
                    while (--i >= 0 && matches.item(i) !== this) {}
                    return i > -1;
                };
        }
    }
});