/**
 * The main controller for the viewer iframe.
 */
Ext.define('Viewer.view.main.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main',
    mixins: ['Viewer.view.main.Inspect'],

    isViewer: true,

    init: function() {
        this.window = this;

        parent.postMessage({
            action: 'mixinDefinitions',
            mixinDefinitions: Fashion.getMixinDefinitions()
        }, '*');

        window.addEventListener('message', this.onMessage.bind(this), false);

        this.initInspect();

        this.on('socketconnect', function() {
            this.postVariables('ready');
            this.postMixins();
        }.bind(this));
    },

    /**
     * Called when a message is received from the Editor app
     * @param e
     */
    onMessage: function(e) {
        var data = e.data;

        switch (data.action) {
            case 'show':
                this.show(data.previewId, data.uiName);
                break;
            case 'componentClasses':
                this.getClassNames();
                break;
            case 'bigMode':
                this.updateBigMode(data.bigMode);
                break;
            case 'setMixins':
                this.setMixins(data.mixins);
                break;
            case 'addHighlight':
                if (data.cmpId) {
                    var cmp = Ext.get(data.cmpId);
                    if (cmp) {
                        cmp.dom.style.backgroundColor = '#FCF3CF';
                    }
                }
                break;
            case 'removeHighlight':
                if (data.cmpId) {
                    var cmp = Ext.get(data.cmpId);
                    if (cmp) {
                        cmp.dom.style.backgroundColor = '';
                    }
                }     
                break;       
        }
    },

    postMixins: function() {
        var themeMixins = Fashion.getMixins();
        if(themeMixins['']) delete themeMixins[''];
        console.log('FASHION: Posting mixins to Editor', themeMixins);
        parent.postMessage({
            action: 'updateMixins',
            mixins: themeMixins
        }, '*');
    },

    setMixins: function(mixins) {
        console.log('FASHION: Saving mixins:', mixins);
        if(mixins['']) delete mixins[''];
        Fashion.saveMixins(mixins);
        // Fashion.onAfterBuild will call `postMixins` after build completes.
    },

    /**
     * Sends all variables to the Editor app
     * @param {String} [action='updateSassVariables']
     */
    postVariables: function(action) {
        action = action || 'updateSassVariables';

        // Re-highlight inspected component in case location/size changed.
        if(this.selectHighlighter && !this.selectHighlighter.isHidden()) {
            this.selectHighlighter.reHighlight();
        }

        var saved = Fashion.getSavedVariables() || {};
        this.saved = {};
        Object.keys(saved).forEach(function(variable) {
            // TODO: CAT-420 Should send hyphens instead of underscores to Fashion.
            this.saved[variable.replace(/-/g, '_')] = saved[variable];
        }.bind(this));

        // fix bug where cmd returns extra spaces in saved variables
        for (var name in this.saved) this.saved[name] = this.saved[name] ? this.saved[name].trim() : this.saved[name];

        var variables = Fashion.getVariables();
        var themeVariables = {};
        Object.keys(variables).forEach(function(variable) {
            // TODO: CAT-420 Should send hyphens instead of underscores to Fashion.
            themeVariables[variable.replace(/-/g, '_')] = variables[variable];
        });

        parent.postMessage({
            action: action,
            variables: themeVariables,
            sources: Fashion.getVariableSources(),
            saved: this.saved
        }, '*');
    },

    /**
     * Displays a component with the given sass variables applied
     * @param {String} previewId The id of the preview to show
     */
    show: function(previewId, uiName) {
        this.previewId = previewId;
        this.uiName = uiName;

        var view = this.lookupReference('mainContainer'),
            xtype = 'c-preview-' + previewId;

        var waitMask = Ext.getCmp('waitMask');
        if (waitMask)  waitMask.destroy();

        try {
            view.removeAll();
        } catch (e) {
            console.log('error removing existing preview', e);
        }

        var cmp = Viewer.view.ExampleComponentFactory.create(previewId, uiName) ||
            (Ext.ClassManager.getByAlias('widget.'+xtype) && {xtype: xtype, cls: 'c-preview-root'});
        if(cmp) {
            view.add(cmp);
        }
    },

    /**
     * Gets class names for all components within a given component
     */
    getClassNames : function () {
        var view = this.lookupReference('mainContainer');
        var children = view.query('component');
        var requiredClassNames = [];
        for (var i=0; i < children.length; i++) {
            var child = children[i];
            if (Ext.ClassManager.get('Ext.panel.Table') && child instanceof Ext.panel.Table) {
                var featureClassNames = this.getFeatureClassNames(child);
                requiredClassNames = Ext.Array.merge(requiredClassNames, featureClassNames);
            }
            var className = this.getProtoClassName(child);
            if (className && !Ext.Array.contains(requiredClassNames, className)) {
                requiredClassNames.push(className);
            }
        }

        parent.postMessage({
            action : 'componentClasses',
            classNames : requiredClassNames
        }, '*');
    },

    onClearGrid : function (btn) {
        var grid = btn.up('grid');
        var store = grid.getStore();
        store.removeAll();
    },

    onRefreshGrid : function (btn) {
        var grid = btn.up('grid');
        grid.getStore().reload();
    },

    /**
     * Adds/removes x-big from the html body element
     * @param bigMode
     */
    updateBigMode: function(bigMode) {
        var htmlEl = Ext.fly(document.querySelector('html'));

        if(bigMode) {
            htmlEl.addCls('x-big');
        } else {
            htmlEl.removeCls('x-big');
        }
    }
});
