Ext.define('Viewer.view.picker.ColorPicker', {
    extend : 'Ext.picker.Color',
    xtype: 'c-preview-color-picker',
    value : '993300'
});