Ext.define('Viewer.view.Progress', {
    extend : 'Ext.Panel',
    xtype : 'c-preview-progress',
    
    requires: [
        'Ext.Progress'
    ],

    layout: {
        type: 'vbox',
        align: 'stretch'
    },
    bodyPadding: 20,

    viewModel: {
        data: {
            progressValue: 0
        },
        formulas: {
            progressText: function(get) {
                return parseInt(get('progressValue')*100) + '% Complete';
            }
        }
    },
    controller: {
        updateProgress: function() {
            var progressValue = this.getViewModel().get('progressValue');
            this.getViewModel().set('progressValue', (progressValue += 0.05) > 1 ? 0 : progressValue);
            Ext.Function.defer(this.updateProgress, 500, this);
        },

        onProgressPainted: function() {
            Ext.Function.defer(this.updateProgress, 500, this);
        }
    },
    
    items: [{
        xtype: 'progress',
        reference: 'progressBar',
        bind: {
            text: '{progressText}',
            value: '{progressValue}'
        },
        listeners: {
            painted: 'onProgressPainted',
            scope: 'controller'
        }
    }]
});